#include "score_collision.h"


int main(int argc, char argv[])
{
int game = 1,sc=30,vi=50;
char ch[10];
SDL_Event event;
SDL_Surface *screen = NULL,*perso1 = NULL,*perso2 = NULL;

SDL_Rect positionperso1,positionperso2;

SDL_Init(SDL_INIT_VIDEO);

perso1= SDL_LoadBMP("zozor.bmp");
perso2= IMG_Load("sapin.png");

screen = SDL_SetVideoMode(700,460,32,SDL_HWSURFACE | SDL_DOUBLEBUF);

positionperso1.x = 20;
positionperso1.y = 150;


positionperso2.x=300;
positionperso2.y=300;



if (screen == NULL)
{
printf("Erreur Loading imahe background\n");
return EXIT_FAILURE;
}

SDL_EnableKeyRepeat(10,10);

while(game)
{
while(SDL_PollEvent(&event)){
switch(event.type)
{

case SDL_QUIT:
game = 0;
break;
case SDL_KEYDOWN:
switch(event.key.keysym.sym)
{
case SDLK_UP: 
positionperso1.y-=5;
break;
case SDLK_DOWN:
positionperso1.y+=5;
break;
case SDLK_RIGHT:
positionperso1.x+=5;
break;
case SDLK_LEFT:
positionperso1.x-=5;
break;

}

break;
}
}

SDL_FillRect(screen,0,SDL_MapRGB(screen->format,255,255,255));
SDL_BlitSurface(perso1,NULL,screen,&positionperso1);
SDL_BlitSurface(perso2,NULL,screen,&positionperso2);
//s'il nya pas de collision
//affichage score initialisé 30
if(col(positionperso1,positionperso2)!=1)
{
affichage_s(screen,score(sc));
affichage_v(screen,vie(vi));
}

//si collision == vrai 
//affichage score-=5
if(col(positionperso1,positionperso2)==1)
{
score(sc);
affichage_s(screen,score(sc));
vie(vi);
affichage_v(screen,vie(vi));
}

//si score diminue jusqua 0
//normalement appel a la fonction d'affichage menu
if(score(sc)==0)
{
score(sc);
affichage_s(screen,score(sc));
vie(vi);
affichage_v(screen,vie(vi));
}

SDL_Flip(screen);

}

SDL_FreeSurface(perso1);
SDL_FreeSurface(perso2);

SDL_Quit();

return EXIT_SUCCESS;

}

