#include <stdio.h>
#include <string.h>
#include "SDL/SDL.h"
#include <stdlib.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>

int col(SDL_Rect pos1,SDL_Rect pos2);
int score(int s);
void affichage_s(SDL_Surface *ecran,int sco);
int vie(int v);
void affichage_v(SDL_Surface *ecranv,int viee);

