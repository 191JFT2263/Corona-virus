pour excuter et complier :

gcc main.c score_collision.c score_collision.h -o prog -lSDL -lSDL_image -lSDL_ttf

./prog
