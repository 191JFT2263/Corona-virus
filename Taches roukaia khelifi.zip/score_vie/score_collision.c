#include "score_collision.h"

int col(SDL_Rect pos1,SDL_Rect pos2)
{
if((pos1.x+pos1.w<pos2.x) || (pos1.x>pos2.x+pos2.w) || (pos1.y+pos1.h<pos2.y) || (pos1.y>pos2.y+pos2.h))
//s'il ya une collision collision=1 si non collision =0
return 0;
else
return 1;
}

int score(int s)
{
int s1;

SDL_Rect pos1;
SDL_Rect pos2;
if(col(pos1,pos2)==1)
//s'il ya une collision le score diminue

s-=5;
s1=s;
return s1;
}

void affichage_s(SDL_Surface *ecran,int sco)
{
char ch[10];


SDL_Surface *e = NULL;
SDL_Rect pos;
TTF_Font *font = NULL;
SDL_Color couleur = {255,0,0};
TTF_Init();

font = TTF_OpenFont("aa.ttf",20);
pos.x = 0;
pos.y = 0;
//convertir le score int -> char
//puis afficher

sprintf(ch,"%d",score(sco));
e = TTF_RenderText_Blended(font,ch,couleur);
SDL_BlitSurface(e,NULL,ecran,&pos);
TTF_CloseFont(font);
TTF_Quit();
SDL_FreeSurface(e);
}


int vie(int v)
{
int v1;
SDL_Rect pos1;
SDL_Rect pos2;
if(col(pos1,pos2)==1)
//si score diminue vie diminue
v-=10;
v1=v;
return v1;
}

void affichage_v(SDL_Surface *ecranv,int viee)
{
char chv[10];
SDL_Surface *ec = NULL;
SDL_Rect posv;
TTF_Font *font = NULL;
SDL_Color couleur = {255,0,0};
TTF_Init();

font = TTF_OpenFont("aa.ttf",20);
posv.x = 100;
posv.y = 0;
//convertir le score int -> char
//puis afficher

sprintf(chv,"%d",vie(viee));
ec = TTF_RenderText_Blended(font,chv,couleur);
SDL_BlitSurface(ec,NULL,ecranv,&posv);
TTF_CloseFont(font);
TTF_Quit();
SDL_FreeSurface(ec);
}
