#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

int width = 640;
int height = 180;
 
int main(int argc, char argv[])
{
        SDL_Init(SDL_INIT_VIDEO);
SDL_WM_SetCaption("teeeeeeeeeeeeeest",NULL);
        SDL_Surface *screen, *background;
        screen = SDL_SetVideoMode(width,height, 32, SDL_SWSURFACE);
SDL_Rect camera_pos;
//      screen = SDL_SetVideoMode(640, 480, 32, SDL_SWSURFACE|SDL_FULLSCREEN);
       int continuer = 1;
        
        background = SDL_LoadBMP("map.bmp");
   	 camera_pos.x = 0;
        camera_pos.y = 0;
        camera_pos.w = 640;
        camera_pos.h = 480;

     SDL_EnableKeyRepeat(10,10);
        while(continuer) {
            
           
	 SDL_Event event;
        while(SDL_PollEvent(&event)) {
  switch(event.type) {
 case SDL_QUIT:
   continuer = 0;
        break;
  case SDL_KEYDOWN:
  switch(event.key.keysym.sym)
   {
 case SDLK_RIGHT:
        camera_pos.x+=5;
     break;
  case SDLK_LEFT:
     camera_pos.x-=5;
   break;
   case SDLK_ESCAPE:
     continuer = 0;
  break;
  }
  break;
                          
   }
  }
                
//if(camera_pos.w==1280)

//camera_pos.w=0;
//scrolling(camera_pos,continuer);
SDL_BlitSurface(background, &camera_pos, screen, NULL);

 
                SDL_Flip(screen);
          
        }
        SDL_FreeSurface(background);

        SDL_Quit();
        return EXIT_SUCCESS;
}
