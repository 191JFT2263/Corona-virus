pour excuter et compiler :

gcc main.c -o prog -lSDL -lSDL_image

./prog
